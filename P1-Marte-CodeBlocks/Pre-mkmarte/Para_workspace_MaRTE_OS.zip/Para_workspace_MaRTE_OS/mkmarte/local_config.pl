# Do NOT edit!!
# Created by 'minstall'
$MPATH="/home/usuario/marte_2.0_22Feb2017";

@AVAILABLE_ARCHS = ("linux","x86","linux_lib");

%GNAT_BIN_PATH = (
	"linux" => "/home/usuario/myapps/gnat/bin/",
	"x86" => "/home/usuario/myapps/gnat/bin/",
	"linux_lib" => "/home/usuario/myapps/gnat/bin/",
	"none" => "none");

%GNAT_LIBS_PATH = (
	"linux" => "/home/usuario/myapps/gnat/lib/gcc/x86_64-pc-linux-gnu/4.9.4",
	"x86" => "/home/usuario/myapps/gnat/lib/gcc/x86_64-pc-linux-gnu/4.9.4",
	"linux_lib" => "/home/usuario/myapps/gnat/lib/gcc/x86_64-pc-linux-gnu/4.9.4",
	"none" => "none");

%GNAT_VERSION = (
	"linux" => "GPL2016",
	"x86" => "GPL2016",
	"linux_lib" => "GPL2016",
	"none" => "none");

return 1;