/*
 * Automatically generated C config: don't edit
 * Linux Kernel Configuration
 */
#define CONFIG_EJEMPLO__II 1
