extern int __isoc99_scanf (const char *__restrict __format, ...) __wur;
