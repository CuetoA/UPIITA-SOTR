#include <stdio.h>         /* comment */
#ifdef CONFIG_EJEMPLO___I
int main(void)
{
 printf("Hello\n");
 printf("Welcome to the Course!\n");

 return 0;
}/*end main()*/
#endif
