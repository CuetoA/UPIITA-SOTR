The routines this math library have been derived from the e500 math
library in eglibc.  The original e500 port to glibc was done by
Aldy Hernandez, <aldyh@redhat.com>, and the port to eglibc was done by
Joseph S. Myers, <joseph@codesourcery.com>

It has been ported to uClibc by Steve Papacharalambous <stevep@freescale.com>
  19 December, 2006

