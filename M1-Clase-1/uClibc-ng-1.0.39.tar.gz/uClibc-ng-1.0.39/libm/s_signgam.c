#include "math.h"
#include "math_private.h"
int signgam = 0;
